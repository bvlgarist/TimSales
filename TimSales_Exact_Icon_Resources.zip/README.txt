TimSales launcher icon resources

Copy the app/ directory into the repository root, replacing AndroidManifest.xml and adding the mipmap-* folders. The icon images are resized directly from the exact square image supplied in chat; no redesign or crop was applied.
